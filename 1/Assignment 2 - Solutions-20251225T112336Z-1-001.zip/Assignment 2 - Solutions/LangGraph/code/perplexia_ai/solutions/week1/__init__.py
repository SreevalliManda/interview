# Week 1 solutions

