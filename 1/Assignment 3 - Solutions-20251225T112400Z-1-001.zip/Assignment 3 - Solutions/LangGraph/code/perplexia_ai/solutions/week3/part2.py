# Part 2 - Agentic RAG implementation.

import os.path as osp
from typing import Dict, List, Optional, Sequence, TypedDict, Annotated

from langchain_core.messages import AnyMessage, HumanMessage, AIMessage, ToolMessage
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.documents import Document
from pydantic import BaseModel, Field

from langgraph.graph import StateGraph, END, START
from langgraph.graph.message import add_messages
from opik.integrations.langchain import OpikTracer

from langgraph.prebuilt import create_react_agent
from langchain_tavily import TavilySearch
from langchain_chroma import Chroma
from langchain_core.tools import tool
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from perplexia_ai.core.chat_interface import ChatInterface
from perplexia_ai.solutions.week3.prompts import (
    QUERY_REWRITER_PROMPT,
    DOCUMENT_SYNTHESIZER_PROMPT,
    DOCUMENT_EVALUATOR_PROMPT,
    AGENT_SYSTEM_PROMPT,
)


# NOTE: Update this to the path of the documents on your machine.
BASE_DIR = "/Users/aish/Downloads/rag_dataset/"
FILE_PATHS = [
    osp.join(BASE_DIR, "2019-annual-performance-report.pdf"),
    osp.join(BASE_DIR, "2020-annual-performance-report.pdf"),
    osp.join(BASE_DIR, "2021-annual-performance-report.pdf"),
    osp.join(BASE_DIR, "2022-annual-performance-report.pdf"),
]
CHROMA_PERSIST_DIRECTORY = "/Users/aish/chroma_db"

class DocumentEvaluation(BaseModel):
    """Evaluation result for retrieved documents."""
    is_sufficient: bool = Field(description="Whether the documents provide sufficient information")
    feedback: str = Field(description="Feedback about the document quality and what's missing")

class RAGState(TypedDict):
    messages: Annotated[Sequence[AnyMessage], add_messages]
    # collected snippets from retriever tool
    retrieved_docs: List[str]
    # evaluator decision
    is_sufficient: Optional[bool]
    # evaluator feedback
    feedback: str
    # rewrite/retrieve loop counter
    iterations: int

def load_docs(paths: List[str]) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    all_docs: List[Document] = []
    for p in paths:
        if not osp.exists(p):
            print(f"WARNING: missing file {p}")
            continue
        pages = PyPDFLoader(p).load()
        combined = "\n".join(pg.page_content for pg in pages)
        for chunk in splitter.split_text(combined):
            all_docs.append(Document(page_content=chunk, metadata={"source": p}))
    return all_docs

class AgenticRAGChat(ChatInterface):
    def __init__(self):
        pass

    def initialize(self):
        # Models
        self.llm = ChatOpenAI(model="gpt-5-mini", reasoning_effort="minimal")
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

        # Vector store
        self.vs = Chroma(
            embedding_function=self.embeddings,
            persist_directory=CHROMA_PERSIST_DIRECTORY,
            collection_name="opm_documents"
        )
        # NOTE: This is a quick way to check if the vector store has any documents
        # instead of loading many documents to check.
        has_existing_documents = len(self.vs.get(limit=1)['ids']) > 0
        if has_existing_documents:
            print("ChromaDB found - reusing existing documents.")
        else:
            print("No existing ChromaDB found - processing and embedding documents...")
            docs = load_docs(FILE_PATHS)
            if docs:
                self.vs.add_documents(docs)

        # Tools
        self.tools = self._create_tools()

        # Agent (ReAct) with access to tools and a system directive
        self.agent = create_react_agent(
            self.llm,
            tools=self.tools,
            prompt=AGENT_SYSTEM_PROMPT,   
        )

        # Graph
        builder = StateGraph(RAGState)
        builder.add_node("agent", self._agent_node)
        builder.add_node("evaluate", self._evaluator_node)
        builder.add_node("rewrite", self._rewriter_node)
        builder.add_node("synthesize", self._synth_node)

        builder.add_edge(START, "agent")
        builder.add_edge("agent", "evaluate")
        builder.add_conditional_edges(
            "evaluate",
            self._route_after_eval,
            {
                "rewrite": "rewrite",
                "synthesize": "synthesize",
            },
        )
        builder.add_edge("rewrite", "agent")
        builder.add_edge("synthesize", END)

        self.graph = builder.compile()
        self.tracer = OpikTracer(graph=self.graph.get_graph(xray=True))

    def _create_tools(self):

        @tool("search_opm_docs")  
        def search_opm_docs(query: str) -> List[str]:
            """Search OPM 2019-2022 documents for passages relevant to the query. Returns a list of short snippets."""
            docs = self.vs.similarity_search(query, k=4)
            snippets: List[str] = []
            for d in docs:
                txt = d.page_content.strip().replace("\n", " ")
                if len(txt) > 500:
                    txt = txt[:500] + " ..."
                src = d.metadata.get("source", "unknown")
                snippets.append(f"[{osp.basename(src)}] {txt}")
            return snippets

        @tool("web_search")
        def web_search(query: str) -> List[str]:
            """Search the web for recent info. Use this tool to fetch real-time web search information."""
            try:
                results = TavilySearch(max_results=3).invoke(query)
                formatted_results = []
                for result in results['results']:
                    formatted_results.append(f"""
                        Title: {result['title']}
                        URL: {result['url']}
                        Content: {result['content']}
                    """)
                return formatted_results
            except Exception as e:
                return [f"Error: {str(e)}"]

        return [search_opm_docs, web_search]

    def _agent_node(self, state: RAGState):
        """
        Run the ReAct agent with current messages.
        Harvest any new ToolMessage outputs from 'search_opm_docs' into state.retrieved_docs.
        """
        result = self.agent.invoke({"messages": state["messages"]})
        new_messages: Sequence[AnyMessage] = result["messages"]

        # Collect tool outputs from appended messages only
        prev_len = len(state["messages"])
        appended = list(new_messages[prev_len:])

        # NOTE: Here we are collecting all the snippets retrieved from the agent in all
        # iterations. Alternatively, we could collect the snippets from the last iteration only.
        new_snippets: List[str] = []
        for m in appended:
            if isinstance(m, ToolMessage):
                payload = m.content
                if isinstance(payload, list):
                    new_snippets.extend([str(x) for x in payload])
                else:
                    new_snippets.append(str(payload))

        return {
            "messages": new_messages,
            "retrieved_docs": state["retrieved_docs"] + new_snippets,
        }

    def _evaluator_node(self, state: RAGState):
        """Simple LLM grader: sets is_sufficient + feedback based on retrieved_docs."""
        user_q = self._first_user_question(state["messages"])

        if not state["retrieved_docs"]:
            return {"is_sufficient": False, "feedback": "No passages retrieved yet. Retrieve first."}

        prompt = DOCUMENT_EVALUATOR_PROMPT.format(
            question=user_q,
            retrieved_docs="\n\n".join(f"- {s}" for s in state["retrieved_docs"]),
        )
        structured_llm = self.llm.with_structured_output(DocumentEvaluation)
        result = structured_llm.invoke(prompt)
        return {"is_sufficient": result.is_sufficient, "feedback": result.feedback}

    def _rewriter_node(self, state: RAGState):
        """LLM rewrites the question using feedback; adds as a new HumanMessage to drive next agent step."""
        user_q = self._first_user_question(state["messages"])
        prompt = QUERY_REWRITER_PROMPT.format(
            question=user_q,
            feedback=state.get("feedback", ""),
            retrieved_docs="\n".join(state.get("retrieved_docs", [])[:5]),
        )
        rewritten = self.llm.invoke(prompt).content.strip()
        return {
            "messages": [HumanMessage(content=rewritten)],
            "iterations": state["iterations"] + 1,
        }

    def _synth_node(self, state: RAGState):
        """LLM synthesizes the final answer from the collected snippets."""
        user_q = self._first_user_question(state["messages"])
        prompt = DOCUMENT_SYNTHESIZER_PROMPT.format(
            question=user_q,
            retrieved_docs="\n\n".join(state["retrieved_docs"]),
        )
        ans = self.llm.invoke(prompt).content
        return {"messages": [AIMessage(content=ans)]}

    def _route_after_eval(self, state: RAGState) -> str:
        """
        Decide next step after evaluation:
        - If sufficient -> 'synthesize'
        - Else if iterations < 3 -> 'rewrite'
        - Else -> 'synthesize' (graceful exit)
        """
        if state.get("is_sufficient", False):
            return "synthesize"
        if state.get("iterations", 0) < 3:
            return "rewrite"
        return "synthesize"

    def run(self, question: str) -> str:
        init: RAGState = {
            "messages": [HumanMessage(content=question)],
            "retrieved_docs": [],
            "is_sufficient": None,
            "feedback": "",
            "iterations": 0,
        }
        out = self.graph.invoke(init)
        return out["messages"][-1].content

    @staticmethod
    def _first_user_question(messages: Sequence[AnyMessage]) -> str:
        for m in messages:
            if isinstance(m, HumanMessage):
                return m.content
        return messages[0].content if messages else ""

    def process_message(self, message: str, chat_history: Optional[List[Dict[str, str]]] = None) -> str:
        """Process a message using the Agentic RAG system."""
        initial_state: RAGState = {
            "messages": [HumanMessage(content=message)],
            "retrieved_docs": [],
            "is_sufficient": None,
            "feedback": "",
            "iterations": 0,
        }

        result = self.graph.invoke(initial_state, config={"callbacks": [self.tracer]})
        return result["messages"][-1].content
