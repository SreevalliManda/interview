"""Perplexia AI - An intelligent AI assistant."""

__version__ = "0.1.0" 